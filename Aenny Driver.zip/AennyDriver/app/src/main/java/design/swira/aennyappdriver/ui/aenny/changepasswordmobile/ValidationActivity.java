package design.swira.aennyappdriver.ui.aenny.changepasswordmobile;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import design.swira.aennyappdriver.R;

public class ValidationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_validation);
    }
}
