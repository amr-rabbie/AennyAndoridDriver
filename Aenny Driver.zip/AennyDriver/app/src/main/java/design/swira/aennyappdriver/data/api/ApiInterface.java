package design.swira.aennyappdriver.data.api;

import java.util.List;

import design.swira.aennyappdriver.pojo.aenny.areas.Areas;
import design.swira.aennyappdriver.pojo.aenny.cities.City;
import design.swira.aennyappdriver.pojo.aenny.client_disablity.ClientDisability;
import design.swira.aennyappdriver.pojo.aenny.clientfavourites.ClientFavouriteResponse;
import design.swira.aennyappdriver.pojo.aenny.clientpaymentsmethods.ClientsPaymentsMethodsResponse;
import design.swira.aennyappdriver.pojo.aenny.clients.Client;
import design.swira.aennyappdriver.pojo.aenny.clients.newclient.ClientResponse;
import design.swira.aennyappdriver.pojo.aenny.disability_types.DisabilityTypes;
import design.swira.aennyappdriver.pojo.aenny.genders.Genders;
import design.swira.aennyappdriver.pojo.aenny.googlemaps.GoogleMapsResponse;
import design.swira.aennyappdriver.pojo.aenny.longtrip.LongTrip;
import design.swira.aennyappdriver.pojo.aenny.notifications.NotificationsResponse;
import design.swira.aennyappdriver.pojo.aenny.paymentsmethods.PaymentsMethodsResponse;
import design.swira.aennyappdriver.pojo.aenny.trips.TripsResponse;
import design.swira.aennyappdriver.pojo.aennydriver.driver.DriverResponse;
import design.swira.aennyappdriver.pojo.test.Response;
import design.swira.aennyappdriver.pojo.test2.WResponse;
import design.swira.aennyappdriver.pojo.test3.MResponse;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiInterface {

    @GET("json")
    public Call<GoogleMapsResponse> getDistanceAndTime(
            @Query("origin") String origin,
            @Query("destination") String destination ,
            @Query("key") String key
    );

    @GET("GetNotificationBySenderId/{userTypeId}/{senderId}")
    public Call<List<NotificationsResponse>> getAllNoficationsByClientId(
            @Path("userTypeId") int userTypeId ,
            @Path("senderId") int senderId
    );

    @FormUrlEncoded
    @POST("DriverLogin/Login")
    public Call<DriverResponse> PostclientLogin(
            @Field("mobile") String mobile,
            @Field("password") String password
    );


    @FormUrlEncoded
    @POST("DriverChangePassword")
    //@FormUrlEncoded
    public Call<DriverResponse> PostchangeClientPassword(
            @Field("mobile") String mobile ,
            @Field("OldPassword") String OldPassword ,
            @Field("NewPassword") String NewPassword
    );








}
