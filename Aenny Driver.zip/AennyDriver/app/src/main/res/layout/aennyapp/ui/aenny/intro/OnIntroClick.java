package design.swira.aennyapp.ui.aenny.intro;

import design.swira.aennyapp.pojo.aenny.clientfavourites.ClientFavouriteResponse;

public interface OnIntroClick {
    void onListClick(int index);
}
