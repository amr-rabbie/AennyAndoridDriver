package design.swira.aennyapp.ui.aenny.changepasswordmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import design.swira.aennyapp.R;

public class ValidationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_validation);
    }
}
