package design.swira.aennyapp.ui.aenny.clientfavourites;

import design.swira.aennyapp.pojo.aenny.clientfavourites.ClientFavouriteResponse;

public interface OnLocationFavouriteClick {
    void onListClick(ClientFavouriteResponse clientFavouriteResponse);
}
