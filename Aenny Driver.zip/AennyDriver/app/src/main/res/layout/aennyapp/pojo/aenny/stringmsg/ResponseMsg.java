package design.swira.aennyapp.pojo.aenny.stringmsg;

public class ResponseMsg {
    String msg;

    public ResponseMsg() {
    }

    public ResponseMsg(String msg) {
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
