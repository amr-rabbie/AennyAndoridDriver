package design.swira.aennyapp.ui.aenny.regsister;

import java.util.List;

import design.swira.aennyapp.pojo.aenny.clients.ClientDisabilitiesItem;

public interface OnDisabilitesSelected {
    public  void OnDisSelected(List<ClientDisabilitiesItem> disabilitiesItems);
}
