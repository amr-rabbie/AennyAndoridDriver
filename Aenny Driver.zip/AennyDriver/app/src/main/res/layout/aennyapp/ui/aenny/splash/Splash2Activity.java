package design.swira.aennyapp.ui.aenny.splash;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import design.swira.aennyapp.R;

public class Splash2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash2);
    }
}
