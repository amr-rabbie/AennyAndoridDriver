package design.swira.aennyapp.pojo.aenny;

public class MyDates {
    String mydate;

    public MyDates(String mydate) {
        this.mydate = mydate;
    }

    public String getMydate() {
        return mydate;
    }

    public void setMydate(String mydate) {
        this.mydate = mydate;
    }
}
